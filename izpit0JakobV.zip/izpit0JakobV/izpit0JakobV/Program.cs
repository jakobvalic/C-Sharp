﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace izpit0JakobV
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
